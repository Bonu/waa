package mum.edu.framework.validator;

import java.util.List;

import mum.edu.domain.Product;

public interface  Validator  {
	
	public List<String> validate(Object  product ) ;
}
